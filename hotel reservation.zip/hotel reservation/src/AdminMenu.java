import api.AdminResource;
import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.text.ParseException;
import java.util.*;

public class AdminMenu {
    int roomNumber;
    double roomPrice;
    AdminResource adminResource = AdminResource.getInstance();

    Scanner scanner = new Scanner(System.in);
    private int roomType;

    public void displayAdminMenu() throws ParseException {
        System.out.println("Admin Menu\n" +
                "-------------------------------------\n" +
                "1.See All Customers\n" +
                "2.See All Rooms\n" +
                "3.See All Reservations\n" +
                "4.Add a Room\n" +
                "5. Back to main Menu\n" +
                "---------------------------------------");

        int i = scanner.nextInt();
        switch (i) {
            case 1:
                SeeAllCustomers();
                break;
            case 2:
                SeeAllRooms();
                break;
            case 3:
                SeeAllReservations();
                break;
            case 4:
                AddARoom();
                break;
            case 5:
                MainMenu mainMenu = new MainMenu();
                mainMenu.displayMainMenu();
                break;
            default:
                System.out.println("Please enter valid input");
                displayAdminMenu();
        }


    }

    private void AddARoom() throws ParseException{
        try {

            System.out.println("Enter room no.");
            String roomNumber = scanner.next();
            System.out.println("Enter price per night ");
            Double roomPrice = scanner.nextDouble();
            System.out.println("Select Type of Room : 1 for SingleBed & 2 for DoubleBed");
            roomType = scanner.nextInt();
            if (scanner.equals("1")) {
                roomType = RoomType.SINGLE.ordinal();
            } else if (scanner.equals("2")) {
                roomType = RoomType.DOUBLE.ordinal();
            } else {
                System.out.println("Type 1 or 2");
//                AddARoom();

            }
            Room room = new Room(roomNumber, roomPrice, RoomType.SINGLE);
            List<Room> rooms = new ArrayList<>();
            rooms.add(room);
            adminResource.addRoom(rooms);
            System.out.println("Room No."+roomNumber + " Room Price:" + roomPrice + " Room Type:" + roomType);
            System.out.println("Would you like to add another room? y/n");
            String nextInput = scanner.next();
            if (nextInput.equals("y")) {
                System.out.println("user selected y");
               AddARoom();
            } else if (nextInput.equals("n")) {
               displayAdminMenu();
            }
        }catch (ParseException e){
            e.printStackTrace();
        }
    }


    private void SeeAllReservations()throws ParseException {
        adminResource.displayAllReservations();
        displayAdminMenu();
    }

    private void SeeAllRooms() throws ParseException {
        Collection<Room> rooms = adminResource.getAllRooms();

        if (!rooms.isEmpty()) {
            for (IRoom room : rooms)
                System.out.println(room);
            displayAdminMenu();
        } else {
            System.out.println("No rooms Found");
            displayAdminMenu();
        }
    }

    private void SeeAllCustomers() throws ParseException{
        try {

            Collection<Customer> customers = adminResource.getAllCustomers();
            if (!customers.isEmpty()) {
                for (Customer customer : customers)
                    System.out.println(customer);
                displayAdminMenu();

            } else {
                System.out.println("No customer found");
                displayAdminMenu();
            }
        }catch (ParseException e){
            e.printStackTrace();
        }

    }
}
package service;

import model.Customer;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

public class CustomerService {

    public static CustomerService customerService=null;
    public static Collection<Customer>customers;

    public CustomerService() {
        this.customers=new ArrayList<>();
    }

    public static CustomerService getInstance(){
        if (customerService == null) {
            customerService = new CustomerService();
        }
        return customerService;
        }

    public void addCustomer(String email, String firstName, String lastName)  {

        customers.add(new Customer(firstName, lastName, email));
        System.out.println("Customer added Successfully");
    }
    public static Customer getCustomer(String customerEmail){
        for (Customer customer:customers) {
            if (customer.getEmail().equals(customerEmail)) {
                return customer;
            }
        }
            return null;
        }
    public Collection<Customer>getAllCustomers(){
        return customers;
    }
}
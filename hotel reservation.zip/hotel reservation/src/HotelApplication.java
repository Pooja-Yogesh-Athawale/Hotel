import java.text.ParseException;

public abstract class HotelApplication {
    public static void main(String[] args) throws ParseException {
        MainMenu.displayMainMenu();

    }
}

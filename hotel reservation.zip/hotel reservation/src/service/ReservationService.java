package service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;

import java.util.*;

public class ReservationService {

    public static ReservationService reservationService = null;
    public static List<Room> rooms;
    public static Collection<Reservation> reservations;

    public ReservationService() {
        this.rooms = new ArrayList<>();
        this.reservations = new HashSet<>();

    }

    public static ReservationService getInstance() {
        if (reservationService == null) {
            reservationService = new ReservationService();
        }
        return reservationService;
    }

    public void addRoom(Room room) {
        rooms.add(room);
        System.out.println("Room added Successfully");

    }

    public IRoom getARoom(List<Room> listOfrooms, String roomId) {

        System.out.println("List ofRooms"+listOfrooms.size());

        for(int i=0;i< listOfrooms.size();i++){
//            System.out.println("comparing roomId="+roomId+"with"+listOfrooms.get(i).getRoomNumber());
            if(listOfrooms.get(i).getRoomNumber().equals(roomId)){
                return listOfrooms.get(i);
            }
        }
//        for (Room room : listOfrooms) {
//
//            System.out.println("comparing roomId="+roomId+"with"+room.getRoomNumber());
//
//            if (room.getRoomNumber().equals(roomId)) {
//                return room;
//            }
//        }
        return null;
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        System.out.println("room "+room.getRoomNumber()+" has been booked successfully");
        return reservation;

    }

    public List<Room>findRooms(Date checkInDate,Date checkOutDate) {
        if (reservations.isEmpty()) {
            return rooms;
        }
        return null;
    }
    public List<Reservation>getCustomersReservation(Customer customer) {
        List<Reservation> customerReservation = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservation.add(reservation);
            }
        }
        return customerReservation;
    }
    public void printAllReservation(){
        if(!reservations.isEmpty()){
            System.out.println(reservations);
        }

    }

    public List<Room> getAllRooms() {
        return rooms;
    }
}

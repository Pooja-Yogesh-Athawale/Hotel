package model;

public class Driver {
    public static void main(String[] args){
        Customer customer=new Customer("pooja","Athawale","pooja@email.com");

        System.out.println(customer);

        }
}
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static java.lang.System.exit;

public class MainMenu {

    public static HotelResource hotelResource = HotelResource.getInstance();
    static Scanner scanner = new Scanner(System.in);

    public MainMenu() {
    }

    public static void displayMainMenu() throws ParseException {
        try {
            System.out.println("Welcome to Hotel Reservation Application\n" +
                    "-----------------------------------------------------------\n" +
                    "1.Find and Reserve a Room\n" +
                    "2.See my Reservations\n" +
                    "3.Create an Account\n" +
                    "4.Admin\n" +
                    "5.Exit\n" +
                    "-------------------------------------------------------------\n" +
                    "Please select a number for the menu option");
            int i = scanner.nextInt();

            switch (i) {
                case 1:
                    findAndReserveARoom();
                    break;
                case 2:
                    seeMyReservations();
                    break;
                case 3:
                    createAnAccount();
                    break;
                case 4:
                    AdminMenu adminMenu = new AdminMenu();
                    adminMenu.displayAdminMenu();
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please enter valid Input");
                    displayMainMenu();

            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static void createAnAccount() throws ParseException {


            scanner.nextLine();
            System.out.println("Enter Email");
            String email = scanner.nextLine();
            System.out.println("Enter First name");
            String firstName = scanner.nextLine();
            System.out.println("Enter Last Name");
            String lastName = scanner.nextLine();

            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("firstName:" + firstName + " lastName:" + lastName + " emailId:" + email);
            System.out.println("Account Created Successfully");
            displayMainMenu();
    }

    private static void seeMyReservations() throws ParseException {

        scanner.nextLine();
        System.out.println("Enter your Email id");
        String email = scanner.nextLine();
        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);
        if (!reservations.isEmpty()) {
            for (Reservation reservation : reservations) {
                System.out.println(reservation);
                displayMainMenu();

            }
        } else {
            System.out.println("No Reservation found");
            displayMainMenu();
        }
    }



    private static void findAndReserveARoom() throws ParseException {


            Calendar calendar = Calendar.getInstance();
            String PATTERN = "mm/dd/yyyy";
            SimpleDateFormat date = new SimpleDateFormat(PATTERN);
            scanner.nextLine();
        try {
                System.out.println("Enter CheckIn Date mm/dd/yyyy:");
                Date todayDate = date.parse(date.format(calendar.getTime()));
                Date checkInDate = new SimpleDateFormat(PATTERN).parse(scanner.next());
                System.out.println("Enter CheckOut Date mm/dd/yyyy:");
                Date checkOutDate = new SimpleDateFormat(PATTERN).parse(scanner.next());
                if (!checkInDate.before(todayDate) && !checkOutDate.before(checkInDate)) {
                    List<Room> rooms = hotelResource.findARoom(checkInDate, checkOutDate);
                    System.out.println("Available Rooms:" + rooms.size());
                    if (!rooms.isEmpty()) {
                        System.out.println("Would you like to book a room? y/n");
                        String confirmbooking = scanner.next();

                        if (confirmbooking.equals("y")) {
                            System.out.println("Enter Email format: name@domain.com");
                            String email = scanner.next();
                            Customer customer = hotelResource.getCustomer(email);
                            if (customer == null) {
                                System.out.println("Sorry! Customer is not registered. Please register");
                                displayMainMenu();
                            }
                            System.out.println("What room number would you like to reserve?");
                            rooms.forEach(System.out::println);
                            String roomNumber = scanner.next();
                            IRoom room = hotelResource.getARoom(rooms, roomNumber);
                            hotelResource.bookARoom(customer.getEmail(), room, checkInDate, checkOutDate);
                            displayMainMenu();
                        } else if (confirmbooking.equals("n")) {
                            displayMainMenu();
                        } else {
                            System.out.println("Invalid input!");
                            displayMainMenu();

                        }

                    } else {
                        System.out.println("First Create An Account");
                        displayMainMenu();
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

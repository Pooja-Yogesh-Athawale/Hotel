package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;
import service.CustomerService;
import service.ReservationService;

import java.text.ParseException;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class HotelResource {
    public static HotelResource hotelResource = null;
    public static CustomerService customerService = CustomerService.getInstance();
    public static ReservationService reservationService = ReservationService.getInstance();

    public HotelResource() {
    }

    public static HotelResource getInstance() {
        if (hotelResource == null) {
            hotelResource = new HotelResource();
        }
        return hotelResource;
    }


    public Customer getCustomer(String email) {
        return CustomerService.getCustomer(email);

    }

    public void createACustomer(String email, String firstName, String lastName) {

            customerService.addCustomer(email, firstName, lastName);


    }

    public IRoom getARoom(List<Room> rooms, String roomNumber) {
        return reservationService.getARoom(rooms, roomNumber);

    }

    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        Customer customer = customerService.getCustomer(customerEmail);
        return reservationService.reserveARoom(customer, room, checkInDate, checkOutDate);

    }

    public List<Reservation> getCustomersReservations(String customerEmail) {
        Customer customer = customerService.getCustomer(customerEmail);
        return reservationService.getCustomersReservation(customer);

    }

    public List<Room> findARoom(Date checkIn, Date checkOut) {
        return reservationService.findRooms(checkIn, checkOut);
    }
}